import './App.css';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Home from './pages/Home';
import Login from './pages/Login';
import Register from './pages/Register';
import Admin from './pages/Admin';
import StockManagement from './pages/StockManagement';
import Orders from './pages/Orders';
import Profile from './pages/Profile';
import ItemPage from './pages/ItemPage.Jsx';
import NotFound from './pages/NotFound';
import Navbar from './components/NavBar';


function App() {
  return (
    <Router>
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/admin" element={<Admin />} />
        <Route path="/item/:id" element={<ItemPage />} />
        <Route path="/stockManagement" element={<StockManagement />} />
        <Route path="/orders" element={<Orders />} />
        <Route path="/profile" element={<Profile />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </Router>
  );
}

export default App;
