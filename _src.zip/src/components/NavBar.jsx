import React, { useContext } from 'react'
import '../styles/Navbar.css'
import { useNavigate } from 'react-router-dom'
import UserContext from '../contexts/UserContext'
import CustomLink from './CustomLink'

const Navbar = () => {
  const { currentUser, updateCurrentUserContext, isRequestToGetCurrentUserDone } = useContext(UserContext);
  const navigate = useNavigate();

  const handleLogout = () => {
    setTimeout(() => {
      localStorage.removeItem("token");
      updateCurrentUserContext(null);
      navigate("/");
    }, 1000);
  }

  return (
    <div className='navbar'>
      <CustomLink to={"/"} children="Home" />
      <div className='navbar-links'>
        {isRequestToGetCurrentUserDone && !currentUser && <CustomLink to={"/login"} children="Login" />}
        {currentUser &&
          <div>
            <CustomLink to={"/profile"} children="Profile" />
            {(currentUser.role == "ADMIN") &&
              <CustomLink to={"/admin"} children="Admin" />
            }
            <button onClick={handleLogout}>Logout</button>
          </div>
        }
      </div>
    </div>
  )
}

export default Navbar