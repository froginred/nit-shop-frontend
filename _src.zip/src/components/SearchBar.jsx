import React from 'react'
import '../styles/SearchBar.css'
import React, { useEffect, useState } from "react";
import { Box, TextField } from "@mui/material";


const SearchBar = () => {
    return (
        <div>SearchBar</div>
    )
}

export default SearchBar