import React from 'react'
import '../styles/CustomLink.css'
import { Link, useResolvedPath, useMatch } from 'react-router-dom'

const CustomLink = ({ to, children, ...rest }) => {
  const resolvedPath = useResolvedPath(to);
  const isActive = useMatch({path: resolvedPath.pathname, end: true});
  
  return (
    <Link to={to} {...rest} className={`custom-link ${isActive ? "active" : ""}`}>{children}</Link>
  )
}

export default CustomLink