import React from 'react'
import '../styles/Order.css'

const Order = () => {
    return (
        <div>Order</div>
    )
}

export default Order