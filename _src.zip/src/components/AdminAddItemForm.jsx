import React from 'react'
import '../styles/AdminAddItemForm.css'

const AdminAddItemForm = () => {
    return (
        <div>AdminAddItemForm</div>
    )
}

export default AdminAddItemForm