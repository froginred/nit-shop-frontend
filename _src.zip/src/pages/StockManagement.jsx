import React from 'react'
import '../styles/StockManagement.css'

const StockManagement = () => {
    return (
        <div>StockManagement</div>
    )
}

export default StockManagement