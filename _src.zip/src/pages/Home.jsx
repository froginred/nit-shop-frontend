import React from 'react'
import '../styles/Home.css'


const Home = () => {
    return (
        <div>Home</div>
    )
}

export default Home