import React from 'react'
import '../styles/Admin.css'

const Admin = () => {
    return (
        <div>Admin</div>
    )
}

export default Admin