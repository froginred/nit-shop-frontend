import React from 'react'
import '../styles/Orders.css'

const Orders = () => {
    return (
        <div>Orders</div>
    )
}

export default Orders