import React from 'react'
import '../styles/SideCart.css'
const SideCart = () => {
    return (
        <div>SideCart</div>
    )
}

export default SideCart