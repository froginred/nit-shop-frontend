import React from 'react'
import '../styles/Item.css'

const Item = () => {
    return (
        <div>Item</div>
    )
}

export default Item