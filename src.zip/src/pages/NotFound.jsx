import React from 'react'
import '../styles/NotFound.css'


const NotFound = () => {
    return (
        <div>NotFound</div>
    )
}

export default NotFound